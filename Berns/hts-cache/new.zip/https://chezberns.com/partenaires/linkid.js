<!DOCTYPE html>   
<!--[if (gte IE 9)|!(IEMobile)|!(IE)]><!--><html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="fr-FR" class="no-js"><!--<![endif]-->        

<!-- BEGIN head -->
<head>
        <meta charset="UTF-8" />
        
        <!-- Mobile Specific Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
     
        <!-- Pingbacks -->
                
        <!-- Calls Wordpress head functions -->
        <title>Page non trouvée &#8211; Chez Bern&#039;s</title>
<link rel='dns-prefetch' href='//maxcdn.bootstrapcdn.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Chez Bern&#039;s &raquo; Flux" href="https://chezberns.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Chez Bern&#039;s &raquo; Flux des commentaires" href="https://chezberns.com/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v7.3.2 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
	var mi_version         = '7.3.2';
	var mi_track_user      = true;
	var mi_no_track_reason = '';
	
	var disableStr = 'ga-disable-UA-79610152-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
	
	if ( mi_track_user ) {
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

		__gaTracker('create', 'UA-79610152-1', 'auto');
		__gaTracker('set', 'forceSSL', true);
		__gaTracker('require', 'displayfeatures');
		__gaTracker('require', 'linkid', 'linkid.js');
		__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
	} else {
		console.log( "" );
		(function() {
			/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
			var noopfn = function() {
				return null;
			};
			var noopnullfn = function() {
				return null;
			};
			var Tracker = function() {
				return null;
			};
			var p = Tracker.prototype;
			p.get = noopfn;
			p.set = noopfn;
			p.send = noopfn;
			var __gaTracker = function() {
				var len = arguments.length;
				if ( len === 0 ) {
					return;
				}
				var f = arguments[len-1];
				if ( typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function' ) {
					console.log( 'Fonction actuellement pas en cours d’exécution __gaTracker(' + arguments[0] + " ....) parce que vous n’êtes pas suivi·e. " + mi_no_track_reason );
					return;
				}
				try {
					f.hitCallback();
				} catch (ex) {

				}
			};
			__gaTracker.create = function() {
				return new Tracker();
			};
			__gaTracker.getByName = noopnullfn;
			__gaTracker.getAll = function() {
				return [];
			};
			__gaTracker.remove = noopfn;
			window['__gaTracker'] = __gaTracker;
					})();
		}
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/chezberns.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.10"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='spoon-shortcodes-css'  href='https://chezberns.com/wp-content/plugins/spoon-shortcodes/css/shortcodes.css?ver=screen' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://chezberns.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='sb_instagram_styles-css'  href='https://chezberns.com/wp-content/plugins/instagram-feed/css/sb-instagram.min.css?ver=1.10.2' type='text/css' media='all' />
<link rel='stylesheet' id='sb-font-awesome-css'  href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-lightbox-swipebox-css'  href='https://chezberns.com/wp-content/plugins/responsive-lightbox/assets/swipebox/css/swipebox.min.css?ver=2.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://chezberns.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.8' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='parent-style-css'  href='https://chezberns.com/wp-content/themes/spoon/style.css?ver=4.9.10' type='text/css' media='all' />
<link rel='stylesheet' id='child-style-css'  href='https://chezberns.com/wp-content/themes/spoon-child/style.css?ver=1.00' type='text/css' media='all' />
<link rel='stylesheet' id='spoon-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto+Condensed%3A300%2C400%2C700%7COpen+Sans%3A300%2C400%2C600%2C700%2C800%7CRoboto+Condensed%3A400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='https://chezberns.com/wp-content/themes/spoon/fonts/fontawesome/css/font-awesome.min.css?ver=screen' type='text/css' media='all' />
<link rel='stylesheet' id='iconfont-pe-stroke-css'  href='https://chezberns.com/wp-content/themes/spoon/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css?ver=screen' type='text/css' media='all' />
<link rel='stylesheet' id='iconfont-pe-stroke-helper-css'  href='https://chezberns.com/wp-content/themes/spoon/fonts/pe-icon-7-stroke/css/helper.css?ver=screen' type='text/css' media='all' />
<link rel='stylesheet' id='spoon-style-css'  href='https://chezberns.com/wp-content/themes/spoon-child/style.css?ver=4.9.10' type='text/css' media='all' />
<link rel='stylesheet' id='prettyphoto-css'  href='https://chezberns.com/wp-content/themes/spoon/css/prettyphoto.css?ver=screen' type='text/css' media='all' />
<link rel='stylesheet' id='spoon-responsive-css'  href='https://chezberns.com/wp-content/themes/spoon/css/layout-responsive.css?ver=screen' type='text/css' media='all' />
<link rel='stylesheet' id='slicknav-css'  href='https://chezberns.com/wp-content/themes/spoon/css/slicknav.css?ver=screen' type='text/css' media='all' />
<script type='text/javascript' src='https://chezberns.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://chezberns.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"https:\/\/chezberns.com","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js?ver=7.3.2'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/responsive-lightbox/assets/swipebox/js/jquery.swipebox.min.js?ver=2.0.5'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/responsive-lightbox/assets/infinitescroll/infinite-scroll.pkgd.min.js?ver=4.9.10'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var rlArgs = {"script":"swipebox","selector":"lightbox","customEvents":"","activeGalleries":"1","animation":"1","hideCloseButtonOnMobile":"0","removeBarsOnMobile":"0","hideBars":"1","hideBarsDelay":"5000","videoMaxWidth":"1080","useSVG":"1","loopAtEnd":"0","woocommerce_gallery":"0","ajaxurl":"https:\/\/chezberns.com\/wp-admin\/admin-ajax.php","nonce":"2423c03856"};
/* ]]> */
</script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/responsive-lightbox/js/front.js?ver=2.0.5'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.8'></script>
<link rel='https://api.w.org/' href='https://chezberns.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://chezberns.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://chezberns.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.10" />
<meta name="generator" content="WooCommerce 3.5.2" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
			<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<meta name="generator" content="Powered by Slider Revolution 5.4.8 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://chezberns.com/wp-content/uploads/2018/10/cropped-logo_2-32x32.png" sizes="32x32" />
<link rel="icon" href="https://chezberns.com/wp-content/uploads/2018/10/cropped-logo_2-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://chezberns.com/wp-content/uploads/2018/10/cropped-logo_2-180x180.png" />
<meta name="msapplication-TileImage" content="https://chezberns.com/wp-content/uploads/2018/10/cropped-logo_2-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
  

        <style type="text/css">
        
			.woocommerce #sidebar .widget_product_categories .cat-item.current-cat a {
			        color: #ff4229;
			        }  
		        </style>


	        <style type="text/css">
				/* RETINA IMAGES */
				@media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) { 
					
						.logo-retina{
							display: table-cell;  
						}
						.logo-regular {
							display: none;
						}                
					               
				}
        </style>
         
        
   

<style type="text/css">

                #topinfo {
                        background-color: #202226;
                        }
                        #topinfo,
                #topinfo a,
                #topinfo a:link,
                #topinfo a:visited,
                #topinfo .socialicons i {
                        color: #ffffff;
                        }
                        #topinfo, #topinfo i  {
                        font-size: 11px;
                        }    
                        #logo-navi-wrap{
                        background-color: rgba(255,255,255,0.90);
                        }
                        .sf-menu a, 
                .sf-menu a:visited, 
                .sf-menu li a, 
                .sf-menu li a:active {
                        color: #2f373c;
                        }
                        
                        .sf-menu a  {
                        font-size: 11px;
                        }    
                        #copyright-text,
                #copyright-text,
		#copyright-text a,
		#copyright-text a:link,
		#copyright-text a:visited,
                #footer .socialicons i {
                        color: #bbbbbb;
                        }
        
        #topinfo a:active,
        #topinfo a:hover,
        #topinfo .socialicons i:hover,  
        .postinfo a:hover,
        a, 
        a:active,
        a:visited,

	.sf-menu a.active,
	.sf-menu li:hover,
	.sf-menu .sfHover,
	.sf-menu a:hover,
	.current-menu-ancestor a,
	.current-menu-parent a,
	ul.sf-menu .current-menu-item:not(.gxg-home) a,
	.slicknav_menu .slicknav_nav a:active,
	.slicknav_menu .slicknav_nav a:hover,
	.slicknav_menu .slicknav_nav .current-menu-item:not(.gxg-home) a,

        h1 a:hover, h1 a:active,
        h2 a:hover, h2 a:active,
        h3 a:hover, h3 a:active,
        h4 a:hover, h4 a:active,
        h5 a:hover, h5 a:active,
        h6 a:hover, h6 a:active,
        #footer-widget-area a:hover,
        #footer-widget-area a:active,
        #copyright-text a:hover,
        #copyright-text a:active,
        .sf-menu ul li a:hover,
        #topnavi .sbOptions a:hover,
        #topnavi .sbOptions a:focus,
        #topnavi .sbOptions a.sbFocus,
	#sidebar a:hover,
	.single-blogentry .share a:hover,
	.more-link i,     
	.menu-tabs .ui-tabs-active .button,
        .comment-nr a:hover,
        h3#reply-title a,

        ul.single-postinfo li a:hover,
        .specialmenuitem
        li.author a:hover,
        .socialicons i:hover, 
        #footer .socialicons i:hover,
        .themecolor 
        	{
                color: #ff4229;
                }

        .highlight1,
        .highlight2,
        #sidebar .tagcloud a,
        ul.login li a:hover,
        span.page-numbers,
        a.page-numbers:hover,
       	.form-submit > input,
       	input[type="submit"],
        #commentform #submit,
        .gallery-resize-icon,
        .separator-line-colored
                {
                background-color: #ff4229;
                }

	input[type="submit"],
        .specialmenuitem {
                border: 2px solid #ff4229;
                } 

        .sticky .post-inner {
                border: 4px solid #ff4229;
                }
        
        
                
        /* hover color */
        	 
	        a:hover,
	        .team-title:hover,
	        .blogtitle a:hover {
	                color: #aaaaaa;
	                }

	        a.button.button-regular:hover,
	        .form-submit > input:hover,
	        #sidebar .tagcloud a:hover,
	        #submit:hover {
	                background-color: #aaaaaa ;
	                }
        


        
	/* FONTS *************************************************************************/

        /* font family */
        h1, h2, h3, h4, h5, h6,
        #topinfo,
        .details,
        .dropcap,
       	.commentlist cite, .commentlist .vcard cite.fn, .commentlist .vcard cite.fn a.url,
        .logo,
        .single-blogentry  .sharetitle,
        .pretty-date,
        .event-time,
        .events .recurring,
        .comment-counter {
	        font-family: "Roboto Condensed"; ?>;
	        }   

	
	        h1, h2, h3, h4, h5, h6,
	        #topinfo,
	        .details,
	        .dropcap,
	       	.commentlist cite, .commentlist .vcard cite.fn, .commentlist .vcard cite.fn a.url,
	        .logo,
	        .single-blogentry  .sharetitle,
	        .comment-counter {
		        font-family: Roboto Condensed;
		        }         
	
		#topinfo,
		.widgettitle,
		.searchresults,
	        .event-title,
	        .pretty-date-top,
	        .pretty-date-bottom,
	        .team-title,
	        .slide-title,
	        .blog-title,
	        .pagetitle,
		.page-title,
		.single-blog-title,
		.menu-cat,
		menu-category-title,
		.menu-title,
		.menu-item-title,
		.overlay .gallery-title,
		.content-box-title,
	        .commentlist cite, .commentlist .vcard cite.fn, .commentlist .vcard cite.fn a.url,
	        .woocommerce ul.products li.product h3, .woocommerce-page ul.products li.product h3 {
		        text-transform: uppercase;
		        }         
	
		.wpcf7 p,
		.wpcf7 input,
		.wpcf7 textarea {
		        text-transform: uppercase;
		        }         
	
</style>

                

</head><!-- END head -->


<!-- BEGIN body -->
<body class="error404 woocommerce-no-js">



<!-- BEGIN header -->
<header  class="stickytop"  >       

	<!-- BEGIN top info bar -->
		
	
	<div id="topinfo">
			
	<div class="social-wrap">
                        <ul class="socialicons">
                                 <li> <a href="https://www.facebook.com/ChezBerns/" target="_blank" class="fb" > <i class="fa fa-facebook"></i> </a> </li>                        
                                 <li> <a href="https://twitter.com/chezberns" target="_blank" class="twitter" > <i class="fa fa-twitter"></i> </a> </li>                        
                                 <li> <a href="https://www.instagram.com/chez_berns/" target="_blank" class="instagram" > <i class="fa fa-instagram"></i> </a> </li>                        
                                 <li> <a href="https://www.linkedin.com/company/chezberns/" target="_blank" class="linkedin" > <i class="fa fa-linkedin"></i> </a> </li>                        
                                                        </ul>
</div><!-- .social--><div class="location-wrap">		               

        <ul class="location location1">
        		                <li><i class="fa fa-phone"></i>
	                	<!--info: do not use intval on $tel_taptocall as it will strip the leading zero -->
	                        <a href="tel:0488140031" class="phonecall">04 88 14 00 31</a>
	                </li>
	        	                <li>06 18 77 12 31</li>
	        
        </ul>

</div>
		                    

	</div>

		<!-- END top info bar -->
		
	<!-- BEGIN logo and navigation wrap -->
	<div id="logo-navi-wrap">
               
        <!-- BEGIN logo -->
<div id="logo-img-retina" class="logo logo-retina">
        <a href="https://chezberns.com/"> 
        	<img class="logoimage" alt="Chez Bern&#039;s" src="https://chezberns.com/wp-content/uploads/2018/10/logo_2.png"     /> 
        </a>
</div>
<div id="logo-img" class="logo logo-regular">
        <a href="https://chezberns.com/" > 
        	<img class="logoimage" alt="Chez Bern&#039;s" src="https://chezberns.com/wp-content/uploads/2018/10/logo_2.png"     /> 
        </a>
</div>
	
<!-- END logo --><!-- BEGIN navigation -->
<nav id="topnavi">   
<div class="menu-main-menu-container"><ul id="menu-main-menu" class="sf-menu regular-menu primary-menu"><li id="menu-item-3977" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a class="section-1099" href="https://chezberns.com#section-1099">Chez Berns</a>
<ul class="sub-menu">
	<li id="menu-item-3982" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/notre-histoire/">Notre Histoire</a></li>
	<li id="menu-item-4473" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/univers/">Notre univers</a></li>
	<li id="menu-item-3969" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/equipe/">L&#8217;équipe</a></li>
	<li id="menu-item-4167" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/en-coulisse/">En coulisse</a></li>
	<li id="menu-item-4134" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/partenaires/">Nos partenaires</a></li>
</ul>
</li>
<li id="menu-item-4053" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a>Votre évènement</a>
<ul class="sub-menu">
	<li id="menu-item-4136" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/mariages/">Votre mariage</a></li>
	<li id="menu-item-4137" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/receptions/">Vos réceptions privées</a></li>
	<li id="menu-item-4138" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/evenements-pro/">Vos évènements professionnels</a></li>
</ul>
</li>
<li id="menu-item-4058" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://chezberns.com/presse/">Presse</a></li>
<li id="menu-item-4396" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://chezberns.com/contact/">Contact</a></li>
</ul></div></nav>

<!-- END navigation -->
	</div>

	<nav id="site-navigation-responsive" class="responsive-menu" role="navigation"></nav>
           
</header>

<div class="clear"></div>

<div id="wrapper">	

        <div id="content-wrap">          
        <div class="blog-content page-wrap grid_12">

		<div id="error404"> <!-- Error Message -->

							<h1> 404</h1>  
				<h2> Not Found</h2> 	
				<p> The page you requested does not exist.</p> 
			
			<!-- Search Form -->
			<div class="searchform404">
				<!-- searchform-->
<form id="searchform" method="get" action="https://chezberns.com/">

	<div class="search-left">
		<i class="fa fa-search"></i>
	</div>

	<div class="search-right">
	<form role="search" method="get" class="search-form" action="https://chezberns.com/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field" placeholder="Rechercher &hellip;" value="" name="s" />
		</label>
	</form>
	</div>

</form>


			</div>

		</div><!-- #error-->   
        
        </div>
        
		</div><!-- #content-->      

		<div id="back-top"> <a href="#top"> <i class="fa fa-arrow-up"></i> </a> </div>

	</div><!-- #wrapper -->
        <div class="clear"></div>

        <footer id="footer">

                 

                <div id="copyright-text" class="small">
                &copy;
                2019                
                                        Chez Bern&#039;s. All Rights Reserved.                                           
                </div>
                
        </footer><!-- #footer -->         

<!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "https://chezberns.com/wp-admin/admin-ajax.php";
</script>
	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/spoon-shortcodes/js/shortcodes.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/chezberns.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var sb_instagram_js_options = {"sb_instagram_at":"","font_method":"svg"};
/* ]]> */
</script>
<script type='text/javascript' src='https://chezberns.com/wp-content/plugins/instagram-feed/js/sb-instagram.min.js?ver=1.10.2'></script>
<script type='text/javascript' src='https://chezberns.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://chezberns.com/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://chezberns.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://chezberns.com/wp-includes/js/imagesloaded.min.js?ver=3.2.0'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.isotope.js?ver=3.0.1'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.waypoints.js?ver=4.0.1'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.waypoints-sticky.js?ver=4.0.1'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.neatshow.js?ver=1.2'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.stellar.js?ver=0.6.1'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.parallax.js?ver=1.1.3'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.prettyphoto.js?ver=3.1.6'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.easing.js?ver=1.3'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.superfish.js?ver=1.4.8'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.lazyload.min.js?ver=1.9.7'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.fittext.js?ver=1.2'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.fitvids.js?ver=1.0'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.selectbox.js?ver=0.2'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/jquery.slicknav.min.js?ver=1.0.10'></script>
<script type='text/javascript' src='https://chezberns.com/wp-content/themes/spoon/js/scripts.js?ver=%20'></script>
<script type='text/javascript' src='https://chezberns.com/wp-includes/js/wp-embed.min.js?ver=4.9.10'></script>

</body>

</html> 